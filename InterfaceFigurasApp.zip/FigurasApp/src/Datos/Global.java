/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Logic.Figura;
import java.util.ArrayList;

/**
 *
 * @author ayrto
 */
public class Global {
        public static ArrayList<Figura> ArregloFiguras = new ArrayList<Figura>();
}
