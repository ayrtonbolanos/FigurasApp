package Logic;
public interface FigurasInterface {
    void Area();
    void Perimetro();
}
