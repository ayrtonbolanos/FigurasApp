package Logica;

/**
 *
 * @author ayrto
 */
public interface SeleccionInterface {
   
    String  Concentrarse();
    String Viaja();
    String Entrenar();
    String jugarPartido();
}
