/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Datos;

import Logica.Selección;
import java.util.ArrayList;

/**
 *
 * @author ayrto
 */
public class ArregloGlobal {
    public static ArrayList<Selección> ArregloSeleccion = new ArrayList<Selección>();    
}
